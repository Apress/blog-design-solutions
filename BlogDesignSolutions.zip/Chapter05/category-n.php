<?php
/*
Template Name: Tutorial Cateogry Template
*/
?>
<?php get_header(); ?>
<div class="narrowcolumn">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<h2>
<?php permalink_anchor(); ?><a href="<?php echo the_permalink(); ?>" rel="bookmark" title="Permanent Link: <?php the_title(); ?>"><?php the_title(); ?></a> 
</h2>
<?php the_excerpt(); ?>
<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
<?php endif; ?>
</div>
<div id="sidebar">
    <ol>    <li>     <a href="http://gorilla.com" title="gorillas">gorilla.com</a>    </li>    <li>    <a href="http://www.kilimanjaro.com/gorilla/websites.htm" title="Gorillas Help Site">kilimanjoaro.com</a>    </li>    <li>    <a href="http://kongisking.com" title="really big gorilla">Kongisking.com</a>	    </li></ol></div>
<?php get_footer(); ?>