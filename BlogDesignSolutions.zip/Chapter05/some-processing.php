<?php
/*
Template Name: Contact Processor
Description: A template for my photosets pages.
*/
?>
<?php
$subj = $HTTP_POST_VARS[subject] . " " . $HTTP_POST_VARS[subjplus];
if ($subj == " ")
	$subj = "Hey Stupid!  Pay Attention!";

$sender = "From: " . $HTTP_POST_VARS[name] . " <" . $HTTP_POST_VARS[email] . ">";
if ($sender == "From:  <>")
	$sender = "From: anonymous <nobody@chrisjdavis.org>";

$messg = stripslashes ( $HTTP_POST_VARS[message] );

function goodPage()
{
?>
<strong>Thank You</strong>
<h2>Your message has been sent by the latest technology, Wi-Fly or <acronym title="Transmission by Carrier Pigeons">TCP</acronym> as it <a href="http://www.notes.co.il/benbasat/5240.asp" title="A New Israeli test confirms: PEI (Pigeon Enabled Internet) is FASTER then ADSL">is sometimes known</a>.</h2>
<p>
Back to <a href="/colophon/" title="Colophon">Colophon</a>.
</p>
<?
}

function badPage()
{
?>
<h1>Oops!</h1>
<h2>there was a problem</h2>
<p class="indent">Your feedback was not sent. Are you sure you included text for the message body? <a href="/colophon/">Please try again.</a></p>
<p>

</p>
</body>
</html>
<?
}
if ($messg)
{
	mail("cjd@chrisjdavis.org", $subj, $messg, $sender);
	goodPage();
}
else
{
	badPage();
}
?>
