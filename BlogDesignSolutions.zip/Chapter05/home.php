<?php get_header(); ?>
<?php require_once (ABSPATH . WPINC . '/rss-functions.php'); ?><?php $today = current_time('mysql', 1); ?><div class="narrowcolumn"><h2>Recent Flickr</h2>
<!-- Start of Flickr Badge -->
<style type="text/css">
#flickr_badge_source_txt {padding:0; font: 11px Arial, Helvetica, Sans serif; color:#666666;}
#flickr_badge_icon {display:block !important; margin:0 !important; border: 1px solid rgb(0, 0, 0) !important;}
#flickr_icon_td {padding:0 5px 0 0 !important;}
.flickr_badge_image {text-align:center !important;}
.flickr_badge_image img {border: 1px solid black !important;}
#flickr_www {display:block; padding:0 10px 0 10px !important; font: 11px Arial, Helvetica, Sans serif !important; color:#3993ff !important;}
#flickr_badge_uber_wrapper a:hover,
#flickr_badge_uber_wrapper a:link,
#flickr_badge_uber_wrapper a:active,
#flickr_badge_uber_wrapper a:visited {text-decoration:none !important; background:inherit !important;color:#3993ff;}
#flickr_badge_wrapper {}
#flickr_badge_source {padding:0 !important; font: 11px Arial, Helvetica, Sans serif !important; color:#666666 !important;}
</style>
<table id="flickr_badge_uber_wrapper" cellpadding="0" cellspacing="10" border="0"><tr><td><a href="http://www.flickr.com" id="flickr_www">www.<strong style="color:#3993ff">flick<span style="color:#ff1c92">r</span></strong>.com</a><table cellpadding="0" cellspacing="10" border="0" id="flickr_badge_wrapper">
<tr>
<script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=2&display=random&size=m&layout=h&source=user&user=45643934%40N00"></script>
</tr>
</table>
</td></tr></table>
<!-- End of Flickr Badge -->
<?php$rss = @fetch_rss('http://www.chrisjdavis.org/feed/');if ( isset($rss->items) && 0 != count($rss->items) ) {?><h3>Latest Posts on <?php bloginfo('name'); ?></h3>        <ol><?php$rss->items = array_slice($rss->items, 0, 5);foreach ($rss->items as $item ) {?><li><a href='<?php echo wp_filter_kses($item['link']); ?>'> <?php echo wp_specialchars($item['title']); ?><small>�<?php echo human_time_diff( strtotime($item['pubdate'], time() ) ); ?><?php _e('ago'); ?></small></li><?php}}?></ol></div><?php get_footer(); ?>