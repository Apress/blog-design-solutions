<?php 
/*
Template Name: Archives Template
Description: A template for my archives pages.
*/
?>
<?php get_header(); ?>
<div class="narrowcolumn">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<h2>
Here are the archives for <?php bloginfo('name'); ?>.
</h2>
<p>
Below you can choose to sort them by category, year, title and date.  Or if you are looking for a post, but don't know the title you can use the handy-dandy search below, have fun.&nbsp; If you are looking for the commenter heat map, scroll to the bottom, or <a href="#heat" title="Commenter Heat Map">click here</a>.
</p>
<p align="center">
<form id="searchform" name="searchform" method="get" action="/index.php">
<input type="search" id="livesearch" name="s" value="search the archives" />
</form>
</p>
<?php echo srg_clean_archives(); ?>
<h2>
Commenter Heat Map<a name="heat"></a>
</h2>
<p>
Below is a heat map of the commenters here. The size of the gravatars are based on the total number of comments for each person. 
</p>
<?php cjd_comment_heat(); ?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>