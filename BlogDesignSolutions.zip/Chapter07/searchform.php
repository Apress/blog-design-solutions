<form action="search.php" method="get">
<h3 id="search">Search</h3>
<p>
<input type="text" name="q" value="" />
<input type="submit" value="Search" />
</p>
</form>

<h3 id="viewarchive"><a href="archive.php">View the Archive</a></h3>