<?php
$db = mysql_connect("localhost", "username", "password") or die("Could not connect to database.");
mysql_select_db("blog",$db);
?>
