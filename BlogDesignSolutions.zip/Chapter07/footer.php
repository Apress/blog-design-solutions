<div id="footer">
<p>A blog by Samuel Pepys.</p>
</div>