-- phpMyAdmin SQL Dump
-- version 2.6.4-pl3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Feb 23, 2006 at 11:20 AM
-- Server version: 4.1.15
-- PHP Version: 5.0.4
-- 
-- Database: `blog`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `comments`
-- 

CREATE TABLE IF NOT EXISTS `comments` (
  `comment_id` int(11) NOT NULL auto_increment,
  `post_id` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `email` varchar(255) NOT NULL default '',
  `website` varchar(255) NOT NULL default '',
  `comment` text NOT NULL,
  `tstamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`comment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `comments`
-- 

INSERT INTO `comments` (`comment_id`, `post_id`, `name`, `email`, `website`, `comment`, `tstamp`) VALUES (1, 2, 'Mrs Turner', 'me@mrsturner.co.uk', 'http://mrsturner.co.uk', 'Yes it was indeed a dreadful play. I fear twas an utter waste of an after noone and I was so glad when it had finished.', '2005-11-26 15:00:00');

-- --------------------------------------------------------

-- 
-- Table structure for table `posts`
-- 

CREATE TABLE IF NOT EXISTS `posts` (
  `post_id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `postdate` datetime NOT NULL default '0000-00-00 00:00:00',
  `summary` text NOT NULL,
  `post` text NOT NULL,
  `tstamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`post_id`),
  FULLTEXT KEY `idx_search` (`title`,`summary`,`post`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `posts`
-- 

INSERT INTO `posts` (`post_id`, `title`, `postdate`, `summary`, `post`, `tstamp`) VALUES (2, 'Knight of the Burning Pestle', '2005-04-03 15:30:00', 'News of the fleet and an afternoon with Mrs. Turner to see a dreadful play.', 'Walked to <a href="#">Westminster</a>; where I understand the news that Mr. Montagu is this last night come to the King with news, that he left the Queen and fleet in the <a href="#">Bay of Biscay</a>, coming this wayward; and that he believes she is now at the Isle of Scilly.\r\n\r\nSo at noon to Paul''s Church Yard; where seeing my Lady''s Sandwich and Carteret, and my wife (who this day made a visit the first time to my Lady Carteret), come by coach, and going to Hide Park, I was resolved to follow them; and so went to Mrs. Turner''s: and thence found her out at the Theatre, where I saw the last act of the "<a href="#">Knight of the Burning Pestle</a>," which pleased me not at all.\r\n\r\nAnd so after the play done, she and The. Turner and Mrs. Lucin and I, in her coach to the Park; and there found them out, and spoke to them; and observed many fine ladies, and staid till all were gone almost.', '2005-11-26 13:56:14');
INSERT INTO `posts` (`post_id`, `title`, `postdate`, `summary`, `post`, `tstamp`) VALUES (3, 'Bad arm', '2004-05-01 23:10:00', 'My arme not being well, I staid within all the morning.', 'My arme not being well, I staid within all the morning, and dined alone at home, my wife being gone out to <a href="#">buy some things</a> for herself, and a gown for me to dress myself in. And so all the afternoon looking over my papers, and at night walked upon the leads, and so to bed.', '2005-05-17 08:51:20');
INSERT INTO `posts` (`post_id`, `title`, `postdate`, `summary`, `post`, `tstamp`) VALUES (4, 'Paying my debts', '2005-03-28 22:15:00', 'Paying my debts and thence to Covent Garden and an Italian puppet play.', 'Up and to my office, and so to dinner at home, and then to several places to pay my debts, and then to <a href="#">Westminster</a> to Dr. Castle, who discoursed with me about Privy Seal business, which I do not much mind, it being little worth, but by Watkins''s - [clerk of the Privy Seal] - late sudden death we are like to lose money.\r\n\r\nSo to the Temple and by water home, and so walk upon the leads, and in the dark there played upon my flageolette, it being a fine still evening, and so to supper and to bed. This day I paid Godfrey''s debt of 40 and odd pounds. The Duke of York went last night to <a href="#">Portsmouth</a>; so that I believe the Queen is near.', '2005-11-26 13:55:55');
