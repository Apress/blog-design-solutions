<div id="header">
<h1><a href="index.php">Samuel's Blog</a></h1>
</div>
